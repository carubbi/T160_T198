// Aula 5 - Exercicio 2 (if...else)
let nota = 6.5;

if (nota >= 7) {
  console.log('Aprovado');
} else {
  console.log('Reprovado');
}
